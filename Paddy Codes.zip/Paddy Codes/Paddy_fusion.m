clear all
clc


load FeaturesDark19_Conv_Paddy
load FeaturesDark19_Pool_Paddy

load FeaturesMobile_FC_Paddy
load FeaturesMobile_Pool_Paddy

load FeaturesResNet18_FC_Paddy
load FeaturesResNet18_Pool_Paddy

%% extract dwt for layer 1

[FeaturesDark19_DWT]=dwt_deepfeatures2(FeaturesDark19_Conv_Paddy);
Dark19DWT=table(FeaturesDark19_DWT',labels);


[FeaturesMobile_DWT]=dwt_deepfeatures2(FeaturesMobile_Pool_Paddy);
MobileDWT=table(FeaturesMobile_DWT',labels);

[FeaturesResNet18_DWT]=dwt_deepfeatures2(FeaturesResNet18_Pool_Paddy);
ResNet18DWT=table(FeaturesResNet18_DWT',labels);

%% extract complexdual tree
[FeaturesDark19_CDT] = Complexdualtree_deepfeatures(FeaturesDark19_Conv_Paddy);
Dark19CDT=table(FeaturesDark19_CDT',labels);

[FeaturesMobile_CDT] = Complexdualtree_deepfeatures(FeaturesMobile_Pool_Paddy);
MobileCDT=table(FeaturesMobile_CDT',labels);

[FeaturesResNet18_CDT] = Complexdualtree_deepfeatures(FeaturesResNet18_Pool_Paddy);
ResNet18CDT=table(FeaturesResNet18_CDT',labels);

%% Combine three dual trees of the three CNNs

CDTThree=[FeaturesDark19_CDT',FeaturesMobile_CDT',FeaturesResNet18_CDT'];
[CDTThree_Cosine] = dct_zigzag(CDTThree',19);
CDTThree_CosineReduced=table(CDTThree_Cosine(:,1:600),labels);

%% apply PCA
[coeff3,score,latent,tsquared,explained] = pca(CDTThree');
PCA_CDTThree=table(coeff3(:,1:300),labels);

%% Combine three FC layers of the three CNNS

FCThree=[FeaturesDark19_Pool_Paddy,FeaturesMobile_FC_Paddy,FeaturesResNet18_FC_Paddy];
FCThreeTable=table(FCThree,labels);

%% Both layers
BothLayers=[FCThree,coeff3(:,1:300)];

BothLayersTable=table(BothLayers,labels);

%% Both layer DCT
BothLayersDCT=[FCThree,CDTThree_Cosine(:,1:500)];

BothLayersDCTTable=table(BothLayersDCT,labels);

