clear all
clc

%% Import DatD:\cervical cancer SipakMedt';
imagefolder='D:\Drive 1\Paddy Disease\Paddy_10classesKaggle';
imds = imageDatastore(imagefolder, 'LabelSource', 'foldernames', 'IncludeSubfolders',true);

% distribution of images in each class
tbl = countEachLabel(imds);

%% Balancing the dataset

% Determine the smallest amount of images in a category
%minSetCount = min(tbl{:,2}); 

% Limit the number of images to reduce the time it takes
% run this example.
%maxNumImages = 100;
%minSetCount = min(maxNumImages,minSetCount);
%% split the dataset for training and testing
% Use splitEachLabel method to trim the set.
%imds = splitEachLabel(imds, minSetCount, 'randomize');
%[trainingSet, testSet] = splitEachLabel(imds, 0.7, 'randomize');
[imdsTrain,imdsValidation] = splitEachLabel(imds, 0.7);
% Notice that each set now has exactly the same number of images.
countEachLabel(imds)

%% Load the network
% Load pretrained network
%net = resnet50();
%net=densenet201();
%net = nasnetmobile();
%net=squeezenet();

%net=darknet19();

net=resnet18();
%net=resnet101();
%net=alexnet();
%net=googlenet();
%net=inceptionv3();
%net=shufflenet();
%net=inceptionresnetv2();
%net=darknet53();
%net=xception();
%net=mobilenetv2();
%% Resize images 
% Create augmentedImageDatastore from training and test sets to resize
% images in imds to the size required by the network.
imageSize = net.Layers(1).InputSize;
augmentedTrainingSet = augmentedImageDatastore(imageSize, imdsTrain, 'ColorPreprocessing', 'gray2rgb');
augmentedTestSet = augmentedImageDatastore(imageSize, imdsValidation, 'ColorPreprocessing', 'gray2rgb');

%% transfer Learning
if isa(net,'SeriesNetwork') 
  lgraph = layerGraph(net.Layers); 
else
  lgraph = layerGraph(net);
end 

[learnableLayer,classLayer] = findLayersToReplace(lgraph);

numClasses = numel(categories(imdsTrain.Labels));

if isa(learnableLayer,'nnet.cnn.layer.FullyConnectedLayer')
    newLearnableLayer = fullyConnectedLayer(numClasses, ...
        'Name','new_fc', ...
        'WeightLearnRateFactor',10, ...
        'BiasLearnRateFactor',10);
    
elseif isa(learnableLayer,'nnet.cnn.layer.Convolution2DLayer')
    newLearnableLayer = convolution2dLayer(1,numClasses, ...
        'Name','new_conv', ...
        'WeightLearnRateFactor',10, ...
        'BiasLearnRateFactor',10);
end

lgraph = replaceLayer(lgraph,learnableLayer.Name,newLearnableLayer);

newClassLayer = classificationLayer('Name','new_classoutput');
lgraph = replaceLayer(lgraph,classLayer.Name,newClassLayer);

% figure('Units','normalized','Position',[0.3 0.3 0.4 0.4]);
% plot(lgraph)
% ylim([0,10])

%% Perform Augmentation
pixelRange = [-25 25];
scaleRange = [1 2];
imageAugmenter = imageDataAugmenter( ...
    'RandXReflection',true, ...
    'RandYReflection',true, ...
    'RandXTranslation',pixelRange, ...
    'RandYTranslation',pixelRange, ...
    'RandXShear',[-30 30], ... 
    'RandXScale',scaleRange, ...
    'RandYScale',scaleRange);
augimdsTrain = augmentedImageDatastore(imageSize,imdsTrain, ...
    'DataAugmentation',imageAugmenter);
%% Resize test Images
augimdsValidation = augmentedImageDatastore(imageSize,imdsValidation);

%% train the network
miniBatchSize = 10;
valFrequency = floor(numel(augimdsTrain.Files)/miniBatchSize);
options = trainingOptions('sgdm', ...
    'MiniBatchSize',miniBatchSize, ...
    'MaxEpochs',20, ...
    'InitialLearnRate',1e-4, ...
    'Shuffle','every-epoch', ...
    'ValidationData',augimdsValidation, ...
    'ValidationFrequency',valFrequency, ...
    'Verbose',false, ...
    'Plots','training-progress');

net = trainNetwork(augimdsTrain,lgraph,options);

%% %% Classification using deep learning
[YPred,probs] = classify(net,augimdsValidation);
accuracy = mean(YPred == imdsValidation.Labels);

%% Extract Features From the layer just before classification
inputSize = net.Layers(1).InputSize;
analyzeNetwork(net)
%layer='global_average_pooling2d_1';
%layer='node_200';
%layer = 'avg_pool';
%layer='pool5';
%layer='prob';
%layer='batchnorm18';
%layer='convolution2dLayer';
%layer='relu_conv10'
%layer='avg1';
layer='new_fc';
%layer='res5b_relu';
% layer='leaky18';
%layer='out_relu';
%layer='conv19';
%layer='new_conv';
featuresTrain2 = activations(net,augimdsTrain,layer,'MiniBatchSize', miniBatchSize, 'OutputAs','rows');
featuresTest2 = activations(net,augimdsValidation,layer,'MiniBatchSize', miniBatchSize,'OutputAs','rows');

whos featuresTrain

%% train an SVM classifier
% Get training labels from the trainingSet
trainingLabels = imdsTrain.Labels;

% Train multiclass SVM classifier using a fast linear solver, and set
% 'ObservationsIn' to 'columns' to match the arrangement used for training
% features.
classifier = fitcecoc(featuresTrain2', trainingLabels', ...
    'Learners', 'Linear', 'Coding', 'onevsall', 'ObservationsIn', 'columns');

%% test the SVM classifier

% Pass CNN image features to trained classifier
predictedLabels = predict(classifier, featuresTest2', 'ObservationsIn', 'columns');

% Get the known labels
testLabels = imdsValidation.Labels;

% Tabulate the results using a confusion matrix.
confMat = confusionmat(testLabels, predictedLabels);

% Convert confusion matrix into percentage form
confMat = bsxfun(@rdivide,confMat,sum(confMat,2));

% Display the mean accuracy
mean(diag(confMat))
D1=[featuresTrain2;featuresTest2];
labelD1=[trainingLabels;testLabels];
dataROP=table(D1,labelD1);